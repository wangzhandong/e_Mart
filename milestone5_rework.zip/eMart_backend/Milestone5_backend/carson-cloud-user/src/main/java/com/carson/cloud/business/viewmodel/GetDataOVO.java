package com.carson.cloud.business.viewmodel;

import lombok.Data;

import java.util.List;

@Data
public class GetDataOVO {
    private List<String> list;
}
