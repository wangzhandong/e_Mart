declare const _default: import("../src/internal").Builder<import("../../core/src/index").JsonObject>;
export default _default;
