import { Configuration } from 'webpack';
import { WebpackConfigOptions } from '../build-options';
export declare function getCommonConfig(wco: WebpackConfigOptions): Configuration;
