package com.iiht.emart.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Service;

import com.iiht.emart.dao.ProductDao;
import com.iiht.emart.entity.ProductEntity;

@Service
public class ProductService {
	@Autowired
	private ProductDao productDao;

	/**
	 * 
	 * @param page
	 * @param pageSize
	 * @return
	 */
	public Page<ProductEntity> findAll(int page, int pageSize) {
		// TODO Auto-generated method stub
		return null;
	}

	/**
	 * select all items product page
	 * 
	 * @return
	 */
	public List<ProductEntity> findAllItems() {
		// TODO Auto-generated method stub
		return productDao.findAllItems();
	}

	/**
	 * select item information by ID product detail page
	 * 
	 * @param
	 * @return
	 */
	public ProductEntity getItemById(Integer id) {
		// TODO Auto-generated method stub
		return productDao.getItemById(id);
	}

	/**
	 * add product
	 * 
	 * @param item
	 * @return
	 */
	public void addItem(ProductEntity item) {
		// TODO Auto-generated method stub
		productDao.addItem(item);
	}

	/**
	 * update product information
	 * 
	 * @param item
	 * @return
	 */
	public ProductEntity updateQty(Integer qty, Integer id) {
		// TODO Auto-generated method stub
		productDao.updateQty(qty, id);
		return productDao.getItemById(id);
	}

	/**
	 * delete product
	 * 
	 * @param id
	 */
	public void deleteItem(Integer id) {
		// TODO Auto-generated method stub
	}

	public void sold(Integer id, Integer qty) {
		Integer sum = productDao.getQty(id) - qty;
		productDao.updateQty(sum, id);
	}

	/**
	 * select all items product page
	 * 
	 * @return
	 */
	public List<ProductEntity> getItemsBySeller(Integer id) {
		// TODO Auto-generated method stub
		return productDao.getItemsBySeller(id);
	}
}
