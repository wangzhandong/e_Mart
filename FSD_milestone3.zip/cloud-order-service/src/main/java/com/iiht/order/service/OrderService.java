package com.iiht.order.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.iiht.order.dao.OrderDao;
import com.iiht.order.entity.OrderEntity;

@Service
public class OrderService {
	@Autowired
	private OrderDao orderDao;

	/**
	 * add order
	 * 
	 * @param item
	 * @return
	 */
	public void addOrder(OrderEntity item) {
		// TODO Auto-generated method stub
	}

	/**
	 * select order information by buyer id
	 * 
	 * @param
	 * @return
	 */
	public List<OrderEntity> getOrderByBuyerId(Integer id) {
		// TODO Auto-generated method stub
		return orderDao.getOrderByBuyerId(id);
	}

	/**
	 * select order information by seller id
	 * 
	 * @param
	 * @return
	 */
	public List<OrderEntity> getOrderBySellerId(Integer id) {
		// TODO Auto-generated method stub
		return orderDao.getOrderBySellerId(id);
	}

}
