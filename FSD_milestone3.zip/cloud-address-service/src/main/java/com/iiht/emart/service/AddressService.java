package com.iiht.emart.service;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.iiht.emart.dao.AddressDao;
import com.iiht.emart.entity.AddressEntity;

@Service
public class AddressService {
	@Autowired
	private AddressDao addressDao;

	Date date = new Date();
	SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd  hh:mm:ss");
	String date1 = sdf.format(date);

	/**
	 * 
	 * @param
	 * @return
	 */
	public List<AddressEntity> findByUser(Integer id) {
		return addressDao.findByUser(id);
	}

	/**
	 * 
	 * @param user
	 * @return
	 */
	public void add(AddressEntity user) {

	}

	/**
	 * 
	 * @param user
	 * @return
	 */
	public AddressEntity updateAddress(String address, Integer id) {
		addressDao.updateAddress(address, id);
		return addressDao.findById(id);
	}

	/**
	 * 
	 * @param id
	 * @return AddressEntity
	 */
	public AddressEntity deleteAddress(Integer id) {
		// TODO Auto-generated method stub
		return null;
	}
}
