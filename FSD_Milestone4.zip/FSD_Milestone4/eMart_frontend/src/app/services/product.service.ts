import { Injectable } from '@angular/core';
import {HttpClient, HttpHeaders} from '@angular/common/http';
import {environment} from '../../environments/environment';

const httpOptions = {
  headers: new HttpHeaders({ 'Content-Type': 'application/json' })
};

@Injectable({
  providedIn: 'root'
})
export class ProductService {

  constructor(private http: HttpClient) { }

  allProducts() {
    return this.http.get(`${environment.baseUrl}/products`, httpOptions);
  }

  searchByName(name){
    return this.http.get(`${environment.baseUrl}/products?name=`+name, httpOptions);
  }

}



