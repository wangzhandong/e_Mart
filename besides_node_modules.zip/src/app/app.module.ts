import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { EmartwelcomeComponent } from './eMart/emartwelcome/emartwelcome.component';
import { BuyerloginComponent } from './eMart/buyerlogin/buyerlogin.component';
import { SellerloginComponent } from './eMart/sellerlogin/sellerlogin.component';
import { SellersignupComponent } from './eMart/sellersignup/sellersignup.component';
import { BuyersignupComponent } from './eMart/buyersignup/buyersignup.component';
import { BuyerhomeComponent } from './eMart/buyerhome/buyerhome.component';
import { MycartComponent } from './eMart/mycart/mycart.component';
import { ApplydiscountComponent } from './eMart/applydiscount/applydiscount.component';
import { SearchitemComponent } from './eMart/searchitem/searchitem.component';
import { ViewdetailsComponent } from './eMart/viewdetails/viewdetails.component';
import { PurchaseshistoryComponent } from './eMart/purchaseshistory/purchaseshistory.component';
import { PurchasedetailsComponent } from './eMart/purchasedetails/purchasedetails.component';
import { AdditemComponent } from './eMart/additem/additem.component';
import { InentoryComponent } from './eMart/inentory/inentory.component';
import { SalesreportComponent } from './eMart/salesreport/salesreport.component';
import { SellerhomeComponent } from './eMart/sellerhome/sellerhome.component';
import { MoneyPipe } from './pipe/money.pipe';
@NgModule({
  declarations: [
    AppComponent,
    EmartwelcomeComponent,
    BuyerloginComponent,
    SellerloginComponent,
    SellersignupComponent,
    BuyersignupComponent,
    BuyerhomeComponent,
    MycartComponent,
    ApplydiscountComponent,
    SearchitemComponent,
    ViewdetailsComponent,
    PurchaseshistoryComponent,
    PurchasedetailsComponent,
    AdditemComponent,
    InentoryComponent,
    SalesreportComponent,
    SellerhomeComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
