import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EmartwelcomeComponent } from './emartwelcome.component';

describe('EmartwelcomeComponent', () => {
  let component: EmartwelcomeComponent;
  let fixture: ComponentFixture<EmartwelcomeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EmartwelcomeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EmartwelcomeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
