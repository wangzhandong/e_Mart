import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-emartwelcome',
  templateUrl: './emartwelcome.component.html',
  styleUrls: ['./emartwelcome.component.scss']
})
export class EmartwelcomeComponent implements OnInit {

  public title:string='This is a Title !--> public parm from .ts ---> bind to html';
  constructor() { }

  ngOnInit() {
  }

}
