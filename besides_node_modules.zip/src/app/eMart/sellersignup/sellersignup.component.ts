import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sellersignup',
  templateUrl: './sellersignup.component.html',
  styleUrls: ['./sellersignup.component.scss']
})
export class SellersignupComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
