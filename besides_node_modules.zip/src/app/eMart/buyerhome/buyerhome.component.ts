import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-buyerhome',
  templateUrl: './buyerhome.component.html',
  styleUrls: ['./buyerhome.component.scss']
})
export class BuyerhomeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
