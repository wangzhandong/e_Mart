import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-viewdetails',
  templateUrl: './viewdetails.component.html',
  styleUrls: ['./viewdetails.component.scss']
})
export class ViewdetailsComponent implements OnInit {

  constructor(public route:ActivatedRoute) { 

  }

  ngOnInit() {
     console.log(this.route.queryParams);
    //this.route.queryParams.subscribe((data)=>{
    //  console.log(data);
    //})
  }
}
