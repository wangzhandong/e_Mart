import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-purchasedetails',
  templateUrl: './purchasedetails.component.html',
  styleUrls: ['./purchasedetails.component.scss']
})
export class PurchasedetailsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
