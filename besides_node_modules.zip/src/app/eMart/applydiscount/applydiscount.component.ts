import { Component, OnInit } from '@angular/core';
import { trigger, state, style, animate, transition } from "@angular/animations";

@Component({
  selector: 'app-applydiscount',
  templateUrl: './applydiscount.component.html',
  styleUrls: ['./applydiscount.component.scss']
})
export class ApplydiscountComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
