import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ApplydiscountComponent } from './applydiscount.component';

describe('ApplydiscountComponent', () => {
  let component: ApplydiscountComponent;
  let fixture: ComponentFixture<ApplydiscountComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ApplydiscountComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ApplydiscountComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
