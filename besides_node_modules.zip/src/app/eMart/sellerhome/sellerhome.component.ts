import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sellerhome',
  templateUrl: './sellerhome.component.html',
  styleUrls: ['./sellerhome.component.scss']
})
export class SellerhomeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
