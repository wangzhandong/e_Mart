import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PurchaseshistoryComponent } from './purchaseshistory.component';

describe('PurchaseshistoryComponent', () => {
  let component: PurchaseshistoryComponent;
  let fixture: ComponentFixture<PurchaseshistoryComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PurchaseshistoryComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PurchaseshistoryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
