import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-purchaseshistory',
  templateUrl: './purchaseshistory.component.html',
  styleUrls: ['./purchaseshistory.component.scss']
})
export class PurchaseshistoryComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
