import { NgForOf } from '@angular/common';
import { Component, OnInit,ViewChild } from '@angular/core';
//import {ProductService} from '../../services/product.service';


interface ProductItem {
  id: string;
  price: number
  title: string;
  desc: string;
  pic: string;
}

@Component({
  selector: 'app-searchitem',
  templateUrl: './searchitem.component.html',
  styleUrls: ['./searchitem.component.scss']
})
export class SearchitemComponent implements OnInit {
  
  @ViewChild('searchResult',{static: false}) searchResult:any;
  public products: ProductItem[];
  //constructor(private productService: ProductService) { }


  ngOnInit(): void {
    this.getDataFromChild();
    //this.productService.allProducts();
  }
  getDataFromChild(){
    // alert('ssssss')
    this.products=this.searchResult.products;
    //console.log(this.searchResult.products)
  }
  onCal(result:string){
    this.getDataFromChild();
  }
}
