import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-inentory',
  templateUrl: './inentory.component.html',
  styleUrls: ['./inentory.component.scss']
})
export class InentoryComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
