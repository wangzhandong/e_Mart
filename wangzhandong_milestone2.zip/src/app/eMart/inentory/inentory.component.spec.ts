import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { InentoryComponent } from './inentory.component';

describe('InentoryComponent', () => {
  let component: InentoryComponent;
  let fixture: ComponentFixture<InentoryComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ InentoryComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(InentoryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
