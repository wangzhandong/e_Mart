import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { EmartwelcomeComponent } from './eMart/emartwelcome/emartwelcome.component';
import { BuyerloginComponent } from './eMart/buyerlogin/buyerlogin.component';
import { SellerloginComponent } from './eMart/sellerlogin/sellerlogin.component';
import { SellersignupComponent } from './eMart/sellersignup/sellersignup.component';
import { BuyersignupComponent } from './eMart/buyersignup/buyersignup.component';
import { BuyerhomeComponent } from './eMart/buyerhome/buyerhome.component';
import { MycartComponent } from './eMart/mycart/mycart.component';
import { ApplydiscountComponent } from './eMart/applydiscount/applydiscount.component';
import { SearchitemComponent } from './eMart/searchitem/searchitem.component';
import { ViewdetailsComponent } from './eMart/viewdetails/viewdetails.component';
import { PurchaseshistoryComponent } from './eMart/purchaseshistory/purchaseshistory.component';
import { PurchasedetailsComponent } from './eMart/purchasedetails/purchasedetails.component';
import { AdditemComponent } from './eMart/additem/additem.component';
import { InentoryComponent } from './eMart/inentory/inentory.component';
import { SalesreportComponent } from './eMart/salesreport/salesreport.component';
import { SellerhomeComponent } from './eMart/sellerhome/sellerhome.component';


const routes: Routes = [
  {
    path:'emartwelcome',component:EmartwelcomeComponent
  },
  {
    path:'buyerlogin',component:BuyerloginComponent
  },
  {
    path:'buyersignup',component:BuyersignupComponent
  },
  {
    path:'sellerlogin',component:SellerloginComponent
  },
  {
    path:'sellersignup',component:SellersignupComponent
  },
  {
    path:'buyerhome',component:BuyerhomeComponent
  },
  {
    path:'mycart',component:MycartComponent
  },
  {
    path:'applydiscount',component:ApplydiscountComponent
  },
  {
    path:'searchitem',component:SearchitemComponent
  },
  {
    path:'viewdetails',component:ViewdetailsComponent
  },
  {
    path:'purchaseshistory',component:PurchaseshistoryComponent
  },
  {
    path:'purchasedetails',component:PurchasedetailsComponent
  },
  {
    path:'additem',component:AdditemComponent
  },
  {
    path:'inentory',component:InentoryComponent
  },
  {
    path:'mycart',component:MycartComponent
  },
  {
    path:'salesreport',component:SalesreportComponent
  },
  {
    path:'sellerhome',component:SellerhomeComponent
  },
  {
    path:'**',redirectTo:'emartwelcome'
  }
];


@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
