export class User {
  id: number;
  username: string;
  password: string;
  usertype: string;
  token?: string;
}
// export class User {
//   id: string;
//   username: string;
//   password: string;
//   email: string;
//   phone: string;
//   address: string;
//   creatDate: string;
//   website: string;
//   GSTIN: string;
//   detail: string;
//   token?: string;
// }