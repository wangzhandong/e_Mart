import { Config } from './config';
export declare let init: (configFile: string, additionalConfig: Config) => void;
